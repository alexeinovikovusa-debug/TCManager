package com.example.tcmanager

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.tcmanager.data.AppDatabase
import com.example.tcmanager.data.Complex
import com.example.tcmanager.data.Document
import com.example.tcmanager.data.Floor
import com.example.tcmanager.data.Inspection
import com.example.tcmanager.data.Queue
import com.example.tcmanager.data.Section
import com.example.tcmanager.data.Work
import com.example.tcmanager.data.WorkType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate

class MainViewModel(private val db: AppDatabase) : ViewModel() {
    val complexes: Flow<List<Complex>> = db.complexDao().all()

    fun seed() {
        viewModelScope.launch(Dispatchers.IO) {
            if (db.complexDao().all().first().isEmpty()) {
                listOf("Меркурий", "Континент", "Маршака").forEach {
                    db.complexDao().insert(Complex(name = it))
                }
            }
            if (db.workTypeDao().all().first().isEmpty()) {
                listOf("Плановое обслуживание", "Ремонт", "Уборка", "Прочее").forEach {
                    db.workTypeDao().insert(WorkType(name = it))
                }
            }
        }
    }

    fun addComplex(name: String, address: String) {
        if (name.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            db.complexDao().insert(Complex(name = name.trim(), address = address.trim()))
        }
    }

    fun inspectionsFor(complexId: Long): Flow<List<Inspection>> =
        db.inspectionDao().forComplex(complexId)

    fun addInspection(complexId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val today = LocalDate.now()
            db.inspectionDao().insert(
                Inspection(
                    complexId = complexId,
                    year = today.year,
                    month = today.monthValue,
                    plannedDate = today.toString()
                )
            )
        }
    }

    fun floorsFor(complexId: Long): Flow<List<Floor>> = db.floorDao().forComplex(complexId)
    fun queuesFor(complexId: Long): Flow<List<Queue>> = db.queueDao().forComplex(complexId)
    fun sectionsFor(complexId: Long): Flow<List<Section>> = db.sectionDao().forComplex(complexId)
    val allSections: Flow<List<Section>> = db.sectionDao().all()
    val workTypes: Flow<List<WorkType>> = db.workTypeDao().all()
    val documents: Flow<List<Document>> = db.documentDao().all()

    fun addFloor(complexId: Long, number: Int, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.floorDao().insert(Floor(complexId = complexId, number = number, name = name.trim()))
        }
    }

    fun addQueue(complexId: Long, number: Int, name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.queueDao().insert(Queue(complexId = complexId, number = number, name = name.trim()))
        }
    }

    fun addSection(complexId: Long, floorId: Long?, queueId: Long?, number: String, area: Double?, purpose: String) {
        if (number.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            db.sectionDao().insert(
                Section(
                    complexId = complexId,
                    floorId = floorId,
                    queueId = queueId,
                    number = number.trim(),
                    area = area,
                    purpose = purpose.trim()
                )
            )
        }
    }

    fun updateSection(section: Section) {
        viewModelScope.launch(Dispatchers.IO) { db.sectionDao().update(section) }
    }

    fun deleteSection(section: Section) {
        viewModelScope.launch(Dispatchers.IO) { db.sectionDao().delete(section) }
    }

    val works: Flow<List<Work>> = db.workDao().all()
    val openFaultsCount: Flow<Int> = db.faultDao().openCount()

    fun addWork(title: String, responsible: String, plannedStart: String?, sectionId: Long?, workTypeId: Long) {
        if (title.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            db.workDao().insert(
                Work(
                    sectionId = sectionId,
                    workTypeId = workTypeId,
                    title = title.trim(),
                    responsible = responsible.trim(),
                    plannedStart = plannedStart?.takeIf { it.isNotBlank() }
                )
            )
        }
    }

    fun advanceWorkStatus(work: Work) {
        val next = when (work.status) {
            "planned" -> "in_progress"
            "in_progress" -> "done"
            else -> return
        }
        viewModelScope.launch(Dispatchers.IO) {
            db.workDao().update(work.copy(status = next))
        }
    }

    fun addDocument(fileName: String, mimeType: String, path: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.documentDao().insert(
                Document(
                    fileName = fileName,
                    mimeType = mimeType,
                    path = path,
                    addedAt = LocalDate.now().toString()
                )
            )
        }
    }

    fun deleteDocument(document: Document) {
        viewModelScope.launch(Dispatchers.IO) { db.documentDao().delete(document) }
    }
}

class MainViewModelFactory(private val db: AppDatabase) : androidx.lifecycle.ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return MainViewModel(db) as T
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        setContent {
            val vm: MainViewModel = viewModel(factory = MainViewModelFactory(db))
            LaunchedEffect(Unit) { vm.seed() }
            AppRoot(vm)
        }
    }
}

private data class BottomTab(val route: String, val label: String)

private val bottomTabs = listOf(
    BottomTab("home", "Главная"),
    BottomTab("objects", "Объекты"),
    BottomTab("works", "Работы"),
    BottomTab("more", "Ещё")
)

@Composable
fun AppRoot(vm: MainViewModel) {
    val navController = rememberNavController()

    MaterialTheme {
        Scaffold(
            bottomBar = {
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = backStackEntry?.destination?.route
                NavigationBar {
                    bottomTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = {
                                if (currentRoute != tab.route) {
                                    navController.navigate(tab.route) {
                                        popUpTo(navController.graph.startDestinationId) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {},
                            label = { Text(tab.label) }
                        )
                    }
                }
            }
        ) { paddingValues ->
            NavHost(
                navController = navController,
                startDestination = "home",
                modifier = Modifier.padding(paddingValues)
            ) {
                composable("home") {
                    DashboardScreen(
                        complexes = vm.complexes,
                        works = vm.works,
                        openFaultsCount = vm.openFaultsCount,
                        inspectionsFor = { id -> vm.inspectionsFor(id) },
                        onOpenPlan = { complexId ->
                            navController.navigate("complex/$complexId")
                        }
                    )
                }
                composable("objects") {
                    ObjectsScreen(
                        complexes = vm.complexes,
                        onOpenComplex = { complexId ->
                            navController.navigate("complex/$complexId")
                        },
                        onAddComplex = { name, address -> vm.addComplex(name, address) }
                    )
                }
                composable("works") {
                    WorksScreen(
                        works = vm.works,
                        sections = vm.allSections,
                        complexes = vm.complexes,
                        workTypes = vm.workTypes,
                        onAddWork = { title, responsible, plannedStart, sectionId, workTypeId ->
                            vm.addWork(title, responsible, plannedStart, sectionId, workTypeId)
                        },
                        onAdvanceStatus = { work -> vm.advanceWorkStatus(work) }
                    )
                }
                composable("more") {
                    MoreScreen(
                        complexes = vm.complexes,
                        works = vm.works,
                        documents = vm.documents,
                        onAddDocument = { fileName, mimeType, path -> vm.addDocument(fileName, mimeType, path) },
                        onDeleteDocument = { document -> vm.deleteDocument(document) }
                    )
                }
                composable(
                    route = "complex/{complexId}",
                    arguments = listOf(navArgument("complexId") { type = NavType.LongType })
                ) { backStackEntry ->
                    val complexId = backStackEntry.arguments?.getLong("complexId") ?: 0L
                    ComplexDetailScreen(
                        complexId = complexId,
                        complexes = vm.complexes,
                        inspections = vm.inspectionsFor(complexId),
                        floors = vm.floorsFor(complexId),
                        queues = vm.queuesFor(complexId),
                        sections = vm.sectionsFor(complexId),
                        onAddInspection = { vm.addInspection(complexId) },
                        onAddFloor = { number, name -> vm.addFloor(complexId, number, name) },
                        onAddQueue = { number, name -> vm.addQueue(complexId, number, name) },
                        onAddSection = { floorId, queueId, number, area, purpose ->
                            vm.addSection(complexId, floorId, queueId, number, area, purpose)
                        },
                        onUpdateSection = { section -> vm.updateSection(section) },
                        onDeleteSection = { section -> vm.deleteSection(section) },
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(
    complexes: Flow<List<Complex>>,
    works: Flow<List<Work>>,
    openFaultsCount: Flow<Int>,
    inspectionsFor: (Long) -> Flow<List<Inspection>>,
    onOpenPlan: (Long) -> Unit
) {
    val list by complexes.collectAsState(initial = emptyList())
    val workList by works.collectAsState(initial = emptyList())
    val faultsCount by openFaultsCount.collectAsState(initial = 0)
    var query by remember { mutableStateOf("") }
    val filtered = list.filter { it.name.contains(query, ignoreCase = true) }

    val today = remember { LocalDate.now().toString() }
    val overdueWorksCount = workList.count {
        it.status != "done" && !it.plannedEnd.isNullOrBlank() && it.plannedEnd!! < today
    }
    val inProgressCount = workList.count { it.status == "in_progress" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("ТехКонтроль", style = MaterialTheme.typography.headlineMedium)
            Text("Управление торговыми комплексами", style = MaterialTheme.typography.bodyMedium)
        }

        item {
            Text("КОМПЛЕКСНЫЕ ПРОВЕРКИ", style = MaterialTheme.typography.titleLarge)
        }

        items(filtered) { complex ->
            val inspectionList by inspectionsFor(complex.id).collectAsState(initial = emptyList())
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(complex.name, style = MaterialTheme.typography.titleLarge)
                    Text(
                        if (inspectionList.isEmpty())
                            "Плановые проверки пока не добавлены"
                        else
                            "Плановых проверок: ${inspectionList.size}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { onOpenPlan(complex.id) }) {
                        Text("Открыть план")
                    }
                }
            }
        }

        item {
            Text("ТРЕБУЕТ ВНИМАНИЯ", style = MaterialTheme.typography.titleLarge)
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Просроченные работы: $overdueWorksCount")
                    Text("Неисправности: $faultsCount")
                    Text("Работы в процессе: $inProgressCount")
                }
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Поиск арендатора или секции") }
            )
        }
    }
}

@Composable
fun ObjectsScreen(
    complexes: Flow<List<Complex>>,
    onOpenComplex: (Long) -> Unit,
    onAddComplex: (name: String, address: String) -> Unit
) {
    val list by complexes.collectAsState(initial = emptyList())
    var showDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Объекты", style = MaterialTheme.typography.headlineMedium) }

        item {
            Button(onClick = { showDialog = true }) {
                Text("+ Добавить комплекс")
            }
        }

        items(list) { complex ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(complex.name, style = MaterialTheme.typography.titleLarge)
                    if (complex.address.isNotBlank()) {
                        Text(complex.address, style = MaterialTheme.typography.bodyMedium)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = { onOpenComplex(complex.id) }) {
                        Text("Подробнее")
                    }
                }
            }
        }
    }

    if (showDialog) {
        AddComplexDialog(
            onDismiss = { showDialog = false },
            onConfirm = { name, address ->
                onAddComplex(name, address)
                showDialog = false
            }
        )
    }
}

@Composable
private fun AddComplexDialog(onDismiss: () -> Unit, onConfirm: (name: String, address: String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый комплекс") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Адрес (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(name, address) }, enabled = name.isNotBlank()) {
                Text("Добавить")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

@Composable
fun ComplexDetailScreen(
    complexId: Long,
    complexes: Flow<List<Complex>>,
    inspections: Flow<List<Inspection>>,
    floors: Flow<List<Floor>>,
    queues: Flow<List<Queue>>,
    sections: Flow<List<Section>>,
    onAddInspection: () -> Unit,
    onAddFloor: (number: Int, name: String) -> Unit,
    onAddQueue: (number: Int, name: String) -> Unit,
    onAddSection: (floorId: Long?, queueId: Long?, number: String, area: Double?, purpose: String) -> Unit,
    onUpdateSection: (Section) -> Unit,
    onDeleteSection: (Section) -> Unit,
    onBack: () -> Unit
) {
    val complexList by complexes.collectAsState(initial = emptyList())
    val complex = complexList.firstOrNull { it.id == complexId }
    val inspectionList by inspections.collectAsState(initial = emptyList())
    val floorList by floors.collectAsState(initial = emptyList())
    val queueList by queues.collectAsState(initial = emptyList())
    val sectionList by sections.collectAsState(initial = emptyList())

    var showFloorDialog by remember { mutableStateOf(false) }
    var showQueueDialog by remember { mutableStateOf(false) }
    var showSectionDialog by remember { mutableStateOf(false) }
    var editingSection by remember { mutableStateOf<Section?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedButton(onClick = onBack) { Text("← Назад") }
        }
        item {
            Text(complex?.name ?: "Комплекс", style = MaterialTheme.typography.headlineMedium)
            val address = complex?.address
            if (!address.isNullOrBlank()) {
                Text(address, style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Text("Плановые проверки", style = MaterialTheme.typography.titleLarge)
        }
        items(inspectionList) { inspection ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("${inspection.month}.${inspection.year} — план: ${inspection.plannedDate}")
                    Text("Статус: ${inspection.status}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Button(onClick = onAddInspection) {
                Text("Добавить плановую проверку")
            }
        }

        item {
            Text("Этажи и очереди", style = MaterialTheme.typography.titleLarge)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (floorList.isEmpty()) "Этажи не добавлены"
                    else "Этажи: " + floorList.joinToString(", ") { f ->
                        if (f.name.isNotBlank()) "${f.number} (${f.name})" else "${f.number}"
                    }
                )
                OutlinedButton(onClick = { showFloorDialog = true }) { Text("+ Добавить этаж") }

                Text(
                    if (queueList.isEmpty()) "Очереди не добавлены"
                    else "Очереди: " + queueList.joinToString(", ") { q ->
                        if (q.name.isNotBlank()) "${q.number} (${q.name})" else "${q.number}"
                    }
                )
                OutlinedButton(onClick = { showQueueDialog = true }) { Text("+ Добавить очередь") }
            }
        }

        item {
            Text("Секции", style = MaterialTheme.typography.titleLarge)
        }
        if (sectionList.isEmpty()) {
            item {
                Text("Секции пока не добавлены", style = MaterialTheme.typography.bodyMedium)
            }
        }
        items(sectionList) { section ->
            val floorLabel = floorList.firstOrNull { it.id == section.floorId }?.let { "этаж ${it.number}" }
            val queueLabel = queueList.firstOrNull { it.id == section.queueId }?.let { "очередь ${it.number}" }
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Секция ${section.number}", style = MaterialTheme.typography.titleMedium)
                    val details = listOfNotNull(
                        floorLabel,
                        queueLabel,
                        section.area?.let { "$it м²" },
                        section.purpose.takeIf { it.isNotBlank() }
                    ).joinToString(" · ")
                    if (details.isNotBlank()) {
                        Text(details, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(
                        if (section.status == "active") "Статус: активна" else "Статус: неактивна",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { editingSection = section }) { Text("Изменить") }
                        OutlinedButton(onClick = { onDeleteSection(section) }) { Text("Удалить") }
                    }
                }
            }
        }
        item {
            Button(onClick = { showSectionDialog = true }) { Text("+ Добавить секцию") }
        }
    }

    if (showFloorDialog) {
        AddFloorDialog(
            onDismiss = { showFloorDialog = false },
            onConfirm = { number, name -> onAddFloor(number, name); showFloorDialog = false }
        )
    }
    if (showQueueDialog) {
        AddQueueDialog(
            onDismiss = { showQueueDialog = false },
            onConfirm = { number, name -> onAddQueue(number, name); showQueueDialog = false }
        )
    }
    if (showSectionDialog) {
        AddSectionDialog(
            floors = floorList,
            queues = queueList,
            onDismiss = { showSectionDialog = false },
            onConfirm = { floorId, queueId, number, area, purpose ->
                onAddSection(floorId, queueId, number, area, purpose)
                showSectionDialog = false
            }
        )
    }
    editingSection?.let { section ->
        EditSectionDialog(
            section = section,
            floors = floorList,
            queues = queueList,
            onDismiss = { editingSection = null },
            onConfirm = { updated -> onUpdateSection(updated); editingSection = null }
        )
    }
}

@Composable
private fun FloorDropdown(floors: List<Floor>, selected: Floor?, onSelected: (Floor?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected?.let { "Этаж ${it.number}" } ?: "Этаж (не выбран)")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Без этажа") }, onClick = { onSelected(null); expanded = false })
            floors.forEach { floor ->
                DropdownMenuItem(
                    text = { Text("Этаж ${floor.number}" + if (floor.name.isNotBlank()) " (${floor.name})" else "") },
                    onClick = { onSelected(floor); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun QueueDropdown(queues: List<Queue>, selected: Queue?, onSelected: (Queue?) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected?.let { "Очередь ${it.number}" } ?: "Очередь (не выбрана)")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Без очереди") }, onClick = { onSelected(null); expanded = false })
            queues.forEach { queue ->
                DropdownMenuItem(
                    text = { Text("Очередь ${queue.number}" + if (queue.name.isNotBlank()) " (${queue.name})" else "") },
                    onClick = { onSelected(queue); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun WorkTypeDropdown(workTypes: List<WorkType>, selected: WorkType?, onSelected: (WorkType) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(selected?.name ?: "Тип работы")
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            workTypes.forEach { workType ->
                DropdownMenuItem(
                    text = { Text(workType.name) },
                    onClick = { onSelected(workType); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun SectionDropdown(
    sections: List<Section>,
    complexNameFor: (Long) -> String,
    selected: Section?,
    onSelected: (Section?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
            Text(
                selected?.let { "${complexNameFor(it.complexId)} — секция ${it.number}" } ?: "Секция (необязательно)"
            )
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(text = { Text("Без секции") }, onClick = { onSelected(null); expanded = false })
            sections.forEach { section ->
                DropdownMenuItem(
                    text = { Text("${complexNameFor(section.complexId)} — секция ${section.number}") },
                    onClick = { onSelected(section); expanded = false }
                )
            }
        }
    }
}

@Composable
private fun AddFloorDialog(onDismiss: () -> Unit, onConfirm: (number: Int, name: String) -> Unit) {
    var number by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый этаж") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("Номер этажа") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(number.toIntOrNull() ?: 0, name) },
                enabled = number.toIntOrNull() != null
            ) { Text("Добавить") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun AddQueueDialog(onDismiss: () -> Unit, onConfirm: (number: Int, name: String) -> Unit) {
    var number by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая очередь") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("Номер очереди") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Название (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(number.toIntOrNull() ?: 0, name) },
                enabled = number.toIntOrNull() != null
            ) { Text("Добавить") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun AddSectionDialog(
    floors: List<Floor>,
    queues: List<Queue>,
    onDismiss: () -> Unit,
    onConfirm: (floorId: Long?, queueId: Long?, number: String, area: Double?, purpose: String) -> Unit
) {
    var number by remember { mutableStateOf("") }
    var area by remember { mutableStateOf("") }
    var purpose by remember { mutableStateOf("") }
    var selectedFloor by remember { mutableStateOf<Floor?>(null) }
    var selectedQueue by remember { mutableStateOf<Queue?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая секция") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("Номер секции") },
                    modifier = Modifier.fillMaxWidth()
                )
                FloorDropdown(floors = floors, selected = selectedFloor, onSelected = { selectedFloor = it })
                QueueDropdown(queues = queues, selected = selectedQueue, onSelected = { selectedQueue = it })
                OutlinedTextField(
                    value = area,
                    onValueChange = { area = it },
                    label = { Text("Площадь, м² (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = purpose,
                    onValueChange = { purpose = it },
                    label = { Text("Назначение (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(selectedFloor?.id, selectedQueue?.id, number, area.toDoubleOrNull(), purpose)
                },
                enabled = number.isNotBlank()
            ) { Text("Добавить") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun EditSectionDialog(
    section: Section,
    floors: List<Floor>,
    queues: List<Queue>,
    onDismiss: () -> Unit,
    onConfirm: (Section) -> Unit
) {
    var number by remember { mutableStateOf(section.number) }
    var area by remember { mutableStateOf(section.area?.toString() ?: "") }
    var purpose by remember { mutableStateOf(section.purpose) }
    var selectedFloor by remember { mutableStateOf(floors.firstOrNull { it.id == section.floorId }) }
    var selectedQueue by remember { mutableStateOf(queues.firstOrNull { it.id == section.queueId }) }
    var active by remember { mutableStateOf(section.status == "active") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Изменить секцию") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("Номер секции") },
                    modifier = Modifier.fillMaxWidth()
                )
                FloorDropdown(floors = floors, selected = selectedFloor, onSelected = { selectedFloor = it })
                QueueDropdown(queues = queues, selected = selectedQueue, onSelected = { selectedQueue = it })
                OutlinedTextField(
                    value = area,
                    onValueChange = { area = it },
                    label = { Text("Площадь, м²") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = purpose,
                    onValueChange = { purpose = it },
                    label = { Text("Назначение") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = active, onCheckedChange = { active = it })
                    Text(if (active) "Секция активна" else "Секция неактивна")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(
                        section.copy(
                            number = number.trim(),
                            floorId = selectedFloor?.id,
                            queueId = selectedQueue?.id,
                            area = area.toDoubleOrNull(),
                            purpose = purpose.trim(),
                            status = if (active) "active" else "inactive"
                        )
                    )
                },
                enabled = number.isNotBlank()
            ) { Text("Сохранить") }
        },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

private fun statusLabel(status: String): String = when (status) {
    "planned" -> "Запланирована"
    "in_progress" -> "В процессе"
    "done" -> "Выполнена"
    else -> status
}

private fun nextStatusLabel(status: String): String? = when (status) {
    "planned" -> "Начать работу"
    "in_progress" -> "Завершить"
    else -> null
}

@Composable
fun WorksScreen(
    works: Flow<List<Work>>,
    sections: Flow<List<Section>>,
    complexes: Flow<List<Complex>>,
    workTypes: Flow<List<WorkType>>,
    onAddWork: (title: String, responsible: String, plannedStart: String?, sectionId: Long?, workTypeId: Long) -> Unit,
    onAdvanceStatus: (Work) -> Unit
) {
    val list by works.collectAsState(initial = emptyList())
    val sectionList by sections.collectAsState(initial = emptyList())
    val complexList by complexes.collectAsState(initial = emptyList())
    val workTypeList by workTypes.collectAsState(initial = emptyList())
    var showDialog by remember { mutableStateOf(false) }

    val sectionsById = remember(sectionList) { sectionList.associateBy { it.id } }
    val workTypesById = remember(workTypeList) { workTypeList.associateBy { it.id } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Работы", style = MaterialTheme.typography.headlineMedium)
            Text(
                "Все текущие и плановые работы по объектам",
                style = MaterialTheme.typography.bodyMedium
            )
        }

        item {
            Button(onClick = { showDialog = true }) {
                Text("+ Добавить работу")
            }
        }

        if (list.isEmpty()) {
            item {
                Text(
                    "Пока нет ни одной работы. Добавьте первую кнопкой выше.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        items(list) { work ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(work.title, style = MaterialTheme.typography.titleLarge)
                    val workType = workTypesById[work.workTypeId]
                    if (workType != null) {
                        Text("Тип работы: ${workType.name}", style = MaterialTheme.typography.bodySmall)
                    }
                    val section = work.sectionId?.let { sectionsById[it] }
                    if (section != null) {
                        Text("Секция: ${section.number}", style = MaterialTheme.typography.bodySmall)
                    }
                    if (work.responsible.isNotBlank()) {
                        Text("Ответственный: ${work.responsible}")
                    }
                    if (!work.plannedStart.isNullOrBlank()) {
                        Text(
                            "Начало: ${work.plannedStart}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Text(
                        "Статус: ${statusLabel(work.status)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    val nextLabel = nextStatusLabel(work.status)
                    if (nextLabel != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(onClick = { onAdvanceStatus(work) }) {
                            Text(nextLabel)
                        }
                    }
                }
            }
        }
    }

    if (showDialog) {
        AddWorkDialog(
            sections = sectionList,
            complexNameFor = { id -> complexList.firstOrNull { it.id == id }?.name ?: "?" },
            workTypes = workTypeList,
            onDismiss = { showDialog = false },
            onConfirm = { title, responsible, plannedStart, sectionId, workTypeId ->
                if (workTypeId != null) {
                    onAddWork(title, responsible, plannedStart, sectionId, workTypeId)
                }
                showDialog = false
            }
        )
    }
}

@Composable
private fun AddWorkDialog(
    sections: List<Section>,
    complexNameFor: (Long) -> String,
    workTypes: List<WorkType>,
    onDismiss: () -> Unit,
    onConfirm: (title: String, responsible: String, plannedStart: String?, sectionId: Long?, workTypeId: Long?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var responsible by remember { mutableStateOf("") }
    var plannedStart by remember { mutableStateOf("") }
    var selectedSection by remember { mutableStateOf<Section?>(null) }
    var selectedWorkType by remember { mutableStateOf(workTypes.firstOrNull()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая работа") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название работы") },
                    modifier = Modifier.fillMaxWidth()
                )
                WorkTypeDropdown(
                    workTypes = workTypes,
                    selected = selectedWorkType,
                    onSelected = { selectedWorkType = it }
                )
                SectionDropdown(
                    sections = sections,
                    complexNameFor = complexNameFor,
                    selected = selectedSection,
                    onSelected = { selectedSection = it }
                )
                OutlinedTextField(
                    value = responsible,
                    onValueChange = { responsible = it },
                    label = { Text("Ответственный") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = plannedStart,
                    onValueChange = { plannedStart = it },
                    label = { Text("Плановая дата начала (гггг-мм-дд)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onConfirm(title, responsible, plannedStart, selectedSection?.id, selectedWorkType?.id)
                },
                enabled = title.isNotBlank() && selectedWorkType != null
            ) {
                Text("Добавить")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Отмена")
            }
        }
    )
}

private fun fileKindLabel(mimeType: String): String = when {
    mimeType.contains("pdf") -> "PDF"
    mimeType.contains("word") || mimeType.contains("msword") -> "Word"
    mimeType.contains("excel") || mimeType.contains("spreadsheet") -> "Excel"
    else -> mimeType
}

@Composable
fun MoreScreen(
    complexes: Flow<List<Complex>>,
    works: Flow<List<Work>>,
    documents: Flow<List<Document>>,
    onAddDocument: (fileName: String, mimeType: String, path: String) -> Unit,
    onDeleteDocument: (Document) -> Unit
) {
    val complexList by complexes.collectAsState(initial = emptyList())
    val workList by works.collectAsState(initial = emptyList())
    val documentList by documents.collectAsState(initial = emptyList())
    val context = LocalContext.current

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val resolver = context.contentResolver
            val mimeType = resolver.getType(uri) ?: "application/octet-stream"
            var displayName = "файл"
            resolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (cursor.moveToFirst() && nameIndex >= 0) {
                    displayName = cursor.getString(nameIndex)
                }
            }
            val docsDir = File(context.filesDir, "documents").apply { mkdirs() }
            val savedFile = File(docsDir, "${System.currentTimeMillis()}_$displayName")
            try {
                resolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(savedFile).use { output ->
                        input.copyTo(output)
                    }
                }
                onAddDocument(displayName, mimeType, savedFile.absolutePath)
            } catch (e: Exception) {
                // не удалось скопировать файл — просто игнорируем
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("Ещё", style = MaterialTheme.typography.headlineMedium) }

        item {
            Text("Сводка", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text("Комплексов в базе: ${complexList.size}")
            Text("Работ в базе: ${workList.size}")
            Text("Работ выполнено: ${workList.count { it.status == "done" }}")
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Документы", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                "Загрузите файлы Excel, PDF или Word — они сохранятся в приложении",
                style = MaterialTheme.typography.bodyMedium
            )
        }

        item {
            Button(onClick = {
                launcher.launch(
                    arrayOf(
                        "application/vnd.ms-excel",
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "application/pdf",
                        "application/msword",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    )
                )
            }) {
                Text("+ Загрузить файл (Excel, PDF, Word)")
            }
        }

        if (documentList.isEmpty()) {
            item {
                Text("Файлы пока не загружены", style = MaterialTheme.typography.bodyMedium)
            }
        }

        items(documentList) { document ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(document.fileName, style = MaterialTheme.typography.titleMedium)
                    Text(fileKindLabel(document.mimeType), style = MaterialTheme.typography.bodySmall)
                    Text("Добавлен: ${document.addedAt}", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(onClick = {
                        File(document.path).delete()
                        onDeleteDocument(document)
                    }) {
                        Text("Удалить")
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(12.dp))
            Text("О программе", style = MaterialTheme.typography.titleLarge)
            Spacer(modifier = Modifier.height(8.dp))
            Text("ТехКонтроль, версия 0.1.0")
            Text(
                "Приложение для управления техническим обслуживанием торговых комплексов.",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
