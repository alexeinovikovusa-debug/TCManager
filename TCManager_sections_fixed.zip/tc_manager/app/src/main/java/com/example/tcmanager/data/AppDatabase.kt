package com.example.tcmanager.data
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface ComplexDao {
    @Query("SELECT * FROM complexes WHERE active=1 ORDER BY name")
    fun all(): Flow<List<Complex>>
    @Insert suspend fun insert(c:Complex):Long
}

@Dao interface FloorDao {
    @Query("SELECT * FROM floors WHERE complexId=:complexId ORDER BY number")
    fun forComplex(complexId:Long): Flow<List<Floor>>
    @Insert suspend fun insert(f:Floor):Long
}

@Dao interface QueueDao {
    @Query("SELECT * FROM queues WHERE complexId=:complexId ORDER BY number")
    fun forComplex(complexId:Long): Flow<List<Queue>>
    @Insert suspend fun insert(q:Queue):Long
}

@Dao interface SectionDao {
    @Query("SELECT * FROM sections WHERE complexId=:complexId ORDER BY number")
    fun forComplex(complexId:Long): Flow<List<Section>>
    @Query("SELECT * FROM sections ORDER BY number")
    fun all(): Flow<List<Section>>
    @Insert suspend fun insert(s:Section):Long
    @Update suspend fun update(s:Section)
    @Delete suspend fun delete(s:Section)
}

@Dao interface WorkTypeDao {
    @Query("SELECT * FROM work_types WHERE active=1 ORDER BY name")
    fun all(): Flow<List<WorkType>>
    @Insert suspend fun insert(w:WorkType):Long
}

@Dao interface InspectionDao {
    @Query("SELECT * FROM inspections WHERE complexId=:complexId ORDER BY plannedDate")
    fun forComplex(complexId:Long): Flow<List<Inspection>>
    @Insert suspend fun insert(i:Inspection):Long
}

@Dao interface WorkDao {
    @Query("SELECT * FROM works ORDER BY CASE status WHEN 'in_progress' THEN 0 WHEN 'planned' THEN 1 WHEN 'done' THEN 2 ELSE 3 END, plannedStart IS NULL, plannedStart")
    fun all(): Flow<List<Work>>
    @Insert suspend fun insert(w:Work):Long
    @Update suspend fun update(w:Work)
}

@Dao interface FaultDao {
    @Query("SELECT COUNT(*) FROM faults WHERE status != 'resolved'")
    fun openCount(): Flow<Int>
}

@Dao interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY addedAt DESC")
    fun all(): Flow<List<Document>>
    @Insert suspend fun insert(d:Document):Long
    @Delete suspend fun delete(d:Document)
}

@Database(
    entities=[Complex::class,Floor::class,Queue::class,Section::class,Tenant::class,Lease::class,WorkType::class,Work::class,FaultType::class,Fault::class,ProjectType::class,Project::class,ProjectFile::class,Inspection::class,InspectionAct::class,Document::class],
    version=1,
    exportSchema=false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun complexDao(): ComplexDao
    abstract fun floorDao(): FloorDao
    abstract fun queueDao(): QueueDao
    abstract fun sectionDao(): SectionDao
    abstract fun workTypeDao(): WorkTypeDao
    abstract fun inspectionDao(): InspectionDao
    abstract fun workDao(): WorkDao
    abstract fun faultDao(): FaultDao
    abstract fun documentDao(): DocumentDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: android.content.Context) = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "tc_manager.db")
                .fallbackToDestructiveMigration()
                .build()
                .also { INSTANCE = it }
        }
    }
}
