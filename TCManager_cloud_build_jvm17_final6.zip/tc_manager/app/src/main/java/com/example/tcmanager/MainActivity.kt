package com.example.tcmanager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.tcmanager.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(private val db:AppDatabase):ViewModel(){ val complexes=db.complexDao().all(); fun seed(){viewModelScope.launch{ if(db.complexDao().all().first().isEmpty()){ listOf("Меркурий","Континент","Маршака").forEach{db.complexDao().insert(Complex(name=it))} } }} }
class MainViewModelFactory(private val db:AppDatabase):androidx.lifecycle.ViewModelProvider.Factory{ override fun <T:ViewModel> create(c:Class<T>):T=MainViewModel(db) as T }

class MainActivity:ComponentActivity(){ override fun onCreate(b:Bundle?){super.onCreate(b); val db=AppDatabase.get(this); setContent{val vm:MainViewModel=viewModel(factory=MainViewModelFactory(db)); LaunchedEffect(Unit){vm.seed()}; Dashboard(vm.complexes)}}}

@Composable fun Dashboard(complexes:Flow<List<Complex>>){val list by complexes.collectAsState(initial=emptyList()); MaterialTheme{Scaffold(bottomBar={NavigationBar{NavigationBarItem(selected=true,onClick={},icon={},label={Text("Главная")});NavigationBarItem(selected=false,onClick={},icon={},label={Text("Объекты")});NavigationBarItem(selected=false,onClick={},icon={},label={Text("Работы")});NavigationBarItem(selected=false,onClick={},icon={},label={Text("Ещё")})}}){p->LazyColumn(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("ТехКонтроль",style=MaterialTheme.typography.headlineMedium);Text("Управление торговыми комплексами",style=MaterialTheme.typography.bodyMedium)};item{Text("КОМПЛЕКСНЫЕ ПРОВЕРКИ",style=MaterialTheme.typography.titleLarge)};items(list){c->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(c.name,style=MaterialTheme.typography.titleLarge);Text("Ежемесячная комплексная проверка",style=MaterialTheme.typography.bodyMedium);Text("План проверок: январь–декабрь 2026",style=MaterialTheme.typography.bodySmall);Spacer(Modifier.height(8.dp));Button(onClick={}){Text("Открыть план")}}}};item{Text("ТРЕБУЕТ ВНИМАНИЯ",style=MaterialTheme.typography.titleLarge);Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Просроченные работы: 0");Text("Неисправности: 0");Text("Работы в процессе: 0")}}};item{OutlinedTextField(value="",onValueChange={},modifier=Modifier.fillMaxWidth(),label={Text("Поиск арендатора или секции")})}}}}}
